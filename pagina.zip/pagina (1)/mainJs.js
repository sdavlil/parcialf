function bNavegacion() {
    const barraNavegacion = document.querySelector('.barraNavegacion');
    barraNavegacion.classList.toggle('oculto');
}

function mostrarFormulario() {
    const formulario = document.querySelector('.form-content');
    formulario.classList.remove('ocultof');
}
